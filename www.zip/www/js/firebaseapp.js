 var config = {
  apiKey: "AIzaSyCvg9N8FDJ1ue3Pv4wlsD33y-IQddbe6N0",
  authDomain: "jede-restaurantes.firebaseapp.com",
  databaseURL: "https://jede-restaurantes.firebaseio.com",
  projectId: "jede-restaurantes",
  storageBucket: "jede-restaurantes.appspot.com",
  messagingSenderId: "140561340388"
};
firebase.initializeApp(config);